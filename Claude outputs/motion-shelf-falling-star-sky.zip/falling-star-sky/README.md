# Falling star sky

The night-sky background from Motion Shelf's task board: a fixed star field,
three constellations, drifting sparks, and a shooting star that crosses the
screen every so often.

Two files do the work, both **copied unchanged** from the project.

## Run it

```
python3 -m http.server 8000
# then open http://localhost:8000/demo.html
```

Leave it open for a minute — the meteors are meant to be occasional.

## Add it to a page

Two things, and both are markup rather than configuration:

```html
<body class="stargazing-page">
  <div class="ambient-background" aria-hidden="true">
    <div class="ambient-morph ambient-morph-one"></div>
    <div class="ambient-morph ambient-morph-two"></div>
    <div class="ambient-sparks" id="ambientSparks"></div>
  </div>

  <!-- your page, above the background -->
  <div class="page">...</div>

  <script type="module">
    /* background.js only exports; the sparks appear when it is called. */
    import { initializeAmbientBackground } from "./scripts/background.js";
    initializeAmbientBackground();
  </script>

  <script type="module" src="./scripts/task-sky.js"></script>
</body>
```

`task-sky.js` looks for `.stargazing-page .ambient-background` and does nothing
at all if it is not there, so it is safe to load on every page of a site.

Your own content needs `position: relative; z-index: 1` (or to sit inside
something that has it) — the background is `position: fixed` at `z-index: 0`.

## How the falling star works

```css
.sky-meteor {
  animation: meteor-pass 31s linear var(--meteor-delay) infinite;
}

@keyframes meteor-pass {
  0%, 3%, 100% { opacity: 0; transform: translate3d(0, 0, 0) rotate(-32deg); }
  3.3%         { opacity: .85; }
  6%           { opacity: 0; transform: translate3d(-380px, 237px, 0) rotate(-32deg); }
}
```

That is the whole trick: **a 31 second cycle in which the meteor is visible for
about 3% of the time.** It appears at 3%, is gone by 6%, and then the element sits
there invisible for another 29 seconds. `task-sky.js` creates three of them at
`4s`, `13s` and `22s` delays and at different positions, so one crosses roughly
every ten seconds and never on a beat you can predict.

It travels down and to the left — `translate3d(-380px, 237px, 0)` — while sitting
at `rotate(-32deg)`, so the streak points along its own path. The tail is just a
140px-wide, 1px-tall element with a `linear-gradient` fading to transparent and a
faint `box-shadow` for the glow.

To make them rarer, lengthen the `31s`. To make them more frequent, add more
`.sky-meteor` elements at other delays. To change the direction, the `translate3d`
and the `rotate` have to agree, or the streak points the wrong way.

The star field is seeded (`seed = 8391`) rather than random, so the sky is the
same every time the page is opened instead of rearranging itself on each visit.

Everything stops under `prefers-reduced-motion: reduce`.

## Files

| | |
| --- | --- |
| `scripts/task-sky.js` | Builds the star field, the constellations and the meteors. Unchanged. |
| `styles/task-sky.css` | The sky palette, the meteor, and `@keyframes meteor-pass`. Unchanged. |
| `scripts/background.js` | The drifting sparks layer. Unchanged. |
| `styles/ambient-layers.css` | The `.ambient-*` rules the sky is painted on, gathered verbatim out of the project's `enhancements.css` and `keyframes.css` so this bundle runs alone. |
| `demo.html` | A page with the required markup and nothing else. |
