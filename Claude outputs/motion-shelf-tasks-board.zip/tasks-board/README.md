# Task board

The whole tasks section of Motion Shelf, lifted out as a page that runs on its own.
Plain HTML, CSS and ES modules — no build step, no framework, no dependencies
beyond two CDN links in the `<head>` (a font and Font Awesome).

Every file here is **copied unchanged** from the project.

## Run it

It uses ES modules, so it needs to be served rather than opened from the file
system:

```
python3 -m http.server 8000
# then open http://localhost:8000/tasks.html
```

## What it does

- **Board view** — one column per contributor plus an unassigned column, drag and
  drop between them.
- **Milestones view** — group tasks under milestones, with import from JSON
  (`tasks/milestone-import.example.json` shows the shape).
- **Rules view** — the working agreements, kept alongside the work.
- Search, and filters for unassigned / per contributor / favourites / important /
  completed.
- Task editor with title, description, assignee, flags and milestone.
- **Copy prompt** on a card, which puts the task's full text on the clipboard —
  it was built to hand a task to an AI.
- The stargazing background: constellations, drifting sparks and the occasional
  shooting star. That part is also packaged on its own as `falling-star-sky`.

## Where the data lives

Two places, and it works with either:

1. **`localStorage`**, always — keys `motion-shelf.tasks.v3` and
   `motion-shelf.milestones.v3` (`scripts/task-config.js`). This is the working
   copy, and it is all you need to try the page.
2. **A linked folder**, optionally — click *Link project* and pick a folder, and
   the board reads and writes `tasks/tasks.json` plus one markdown file per
   contributor, so the board can be committed and shared through git. That uses
   the File System Access API, which today means a Chromium browser; without it
   the button simply does not appear and `localStorage` carries on alone.

`tasks/` in this bundle holds a real snapshot: `tasks.json`, and
`Gabriel.md` / `Rati.md` / `Georgi.md` generated from it.

## Adapting it

- **Contributors** are the `CONTRIBUTORS` array at the top of
  `scripts/task-config.js`. Change the names there and the columns, the filters
  and the markdown files all follow.
- **Storage keys** are in the same file — change them if you run more than one
  board in the same origin.
- **Nothing is hard-coded to a path.** The linked folder is whatever the user
  picks.

## Files

| | |
| --- | --- |
| `tasks.html` | The page. |
| `scripts/tasks.js` | Board, milestones, editor, drag and drop, filters. |
| `scripts/task-config.js` | Contributors, storage keys, task and milestone shapes. |
| `scripts/task-storage.js` | localStorage, and reading/writing the linked folder. |
| `scripts/task-sky.js` | The stargazing background: stars, constellations, meteors. |
| `scripts/background.js` | The drifting ambient sparks shared with the rest of the app. |
| `scripts/filesystem.js` | Linking a project folder and remembering the handle. |
| `scripts/scroll-progress.js` | The progress line at the top of the page. |
| `scripts/state.js`, `code.js`, `utils.js`, `storage.js`, `animations.js`, `easing.js`, `preview-scene.js` | Shared with the animation library; pulled in because `tasks.js` imports from them. |
| `styles/tasks.css`, `task-sky.css` | Tasks-only styling. |
| `styles/*.css` (the rest) | Shared app styling — base, header, modals, forms, toasts, keyframes. |
