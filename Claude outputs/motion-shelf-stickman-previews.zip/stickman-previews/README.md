# Stick figure previews

Drop-in artwork for anything that needs a placeholder image with **visible motion** —
an animation library, a component gallery, an empty state. Each item gets a little
stick figure doing something, drawn as inline SVG with CSS-animated limbs.

No image files, no network, no dependencies, no build step. One ES module.

## What it produces

`createFigurePreview(item)` returns a `data:image/svg+xml,...` URI you can put
straight into an `<img src>` or a CSS `background-image`.

Twelve activities: walking, running, sitting, smoking, waving, jumping, dancing,
reading, drinking coffee, thinking, stretching, skateboarding. Twelve colours.

Which one an item gets is **derived from the item's own id**, so the grid looks
varied but a given card keeps the same character and colour between renders and
across reloads. Nothing is random at display time.

The figure's name is printed along the bottom of the drawing, and the limbs
animate inside the SVG itself — which is why it works in an `<img>`, where
external CSS cannot reach.

`prefers-reduced-motion: reduce` stops every limb.

## Use it

```js
import { createFigurePreview } from "./preview-figures.js";

const image = document.createElement("img");
image.src = createFigurePreview({ id: item.id, name: item.name });
```

The argument is an object; it reads `id`, then `className`, then `name`, and
falls back to a constant. `name` is also drawn as the caption (escaped, cut at 34
characters).

Also exported:

- `pickFigure(key)` → `{ activity, color }`, if you want the choice without the drawing.
- `FIGURE_ACTIVITIES` → the list of activity names.

The drawing is `320 × 240` (4:3). If your frame is a different shape, use
`object-fit: contain` rather than `cover`, or the head gets cropped:

```css
.preview { aspect-ratio: 4 / 3; overflow: hidden; }
.preview img { width: 100%; height: 100%; object-fit: contain; }
```

## Read this before you ship it

`preview-figures.js` is the file exactly as it was in Motion Shelf, unedited.
**It has one real bug**, and it is worth knowing about:

```js
color: PALETTE[(seed >> 5) % PALETTE.length],
```

`seed` is an unsigned 32-bit FNV-1a hash. `>>` is the *signed* shift, so any
seed above 2^31 comes back negative, the modulo stays negative, and `PALETTE[-3]`
is `undefined` — the figure is drawn with `fill="undefined"`, which renders black.
Measured over 4000 ids: **47% of them** come out black.

`preview-figures.fixed.js` is the same file with that one character changed
(`>>` → `>>>`) and nothing else. Use that one, or apply the fix yourself. The
same care applies anywhere else you hash-and-shift.

## Files

| File | |
| --- | --- |
| `preview-figures.js` | The original, untouched. |
| `preview-figures.fixed.js` | Identical except for the `>>` → `>>>` fix above. |
| `demo.html` | Open it in a browser: every activity, side by side, animating. |
